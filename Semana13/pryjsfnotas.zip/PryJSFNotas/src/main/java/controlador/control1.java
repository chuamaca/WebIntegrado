
package controlador;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.io.Serializable;
import dao.Negocio;
import beans.*;
import java.util.*;
import javax.annotation.PostConstruct;
@ManagedBean
@ViewScoped
public class control1 implements Serializable {
private List<Alumno> lisalu;
private List<Pagos>  lispago;
private String nombre;
private double total;
private String texto;

@PostConstruct //anotacion que se ejecuta cunado la pagina asociada se carge    
public void init(){
    lisalu=new Negocio().LisAlu();
}
public void verpago(Alumno a){
    lispago=new Negocio().LisPago(a.getCoda());
    nombre=a.getApe()+","+a.getNoma();
    total=0;
    for(Pagos x:lispago){
        total=+x.getMonto();
    }
}


public void filtra(){
    lisalu=new Negocio().LisAlu(texto);
}

    public control1() {
      texto="";
    }

    public List<Alumno> getLisalu() {
        return lisalu;
    }

    public void setLisalu(List<Alumno> lisalu) {
        this.lisalu = lisalu;
    }

    public List<Pagos> getLispago() {
        return lispago;
    }

    public void setLispago(List<Pagos> lispago) {
        this.lispago = lispago;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
    
}
