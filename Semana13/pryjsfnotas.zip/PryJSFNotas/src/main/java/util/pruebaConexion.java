package util;

public class pruebaConexion {

    public static void main(String[] args) {
      MySQLConexion.getConexion();
    }
    
}
